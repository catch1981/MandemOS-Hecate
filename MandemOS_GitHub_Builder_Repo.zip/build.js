#!/usr/bin/env node
console.log("MandemOS EXE launcher ready.");
